package test;

public class UserBean {

	private String userID;
	private String userName;
	private String userDepartment;
	private String userPositionCode;
	private String userPassword;
	private String userDescription;
	private String userAffiliation;

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setUserDepartment(String userDepartment) {
		this.userDepartment = userDepartment;
	}

	public void setUserPositionCode(String userPositionCode) {
		this.userPositionCode = userPositionCode;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public void setUserDescription(String userDescription) {
		this.userDescription = userDescription;
	}

	public void setUserAffiliation(String userAffiliation) {
		this.userAffiliation = userAffiliation;
	}

	public String getUserID() {
		return userID;
	}

	public String getUserName() {
		return userName;
	}

	public String getUserDepartment() {
		return userDepartment;
	}

	public String getUserPositionCode() {
		return userPositionCode;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public String getUserDescription() {
		return userDescription;
	}

	public String getUserAffiliation() {
		return userAffiliation;
	}

}
